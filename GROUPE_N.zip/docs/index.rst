.. rules documentation master file, created by
   sphinx-quickstart on Wed Dec 08 21:00:00 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Rules' documentation!
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   Introduction <README>
   Application Programming Interface <api>

Indices and tables
==================

* :ref:`genindex`


