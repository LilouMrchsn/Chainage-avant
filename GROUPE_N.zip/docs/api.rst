Application Programming Interface
=================================

.. toctree::
   :maxdepth: 2

   Rules <rules>

